import { Tabs } from "expo-router";
// import Icon from 'react-native-vector-icons/FontAwesome';

export default function RootLayout() {

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: '#f0f6fc',
                tabBarInactiveTintColor: '#8b949e',
                tabBarStyle: {
                    backgroundColor: '#0d1117',
                    borderTopWidth: 0,
                    height: 60,
                    paddingBottom: 5,
                },
                headerShown: false,
            }}
            initialRouteName="index"
        >
            <Tabs.Screen
                name="index"
                options={{
                    title: "Главная",
                    // tabBarIcon: ({ color }) => (
                    //     <Icon name="home" size={24} color={color} />
                    // ),
                }}
            />

            <Tabs.Screen
                name="screens/ImageByDate"
                options={{
                    title: "By date",

                }}
            />

            <Tabs.Screen
                name="screens/ImagesByDate"
                options={{
                    title: "Images by date",
                }}
            />

            <Tabs.Screen
                name="screens/ImagesRandom"
                options={{
                    title: "Random images",
                }}
            />
        </Tabs>
    );
}
